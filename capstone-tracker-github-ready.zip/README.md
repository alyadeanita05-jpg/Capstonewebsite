# Capstone Tracker

Website manajemen dan monitoring tugas besar (Capstone Project) mahasiswa berbasis kelompok secara real-time.

## Cara Menjalankan & Deploy ke Vercel:
1. Upload seluruh file dalam folder ini (`package.json`, `vite.config.js`, `index.html`, dan folder `src/`) ke repository GitHub kamu.
2. Buka `src/App.jsx` dan isi `firebaseConfig` dengan konfigurasi project Firebase kamu (aktifan **Authentication -> Email/Password** dan **Firestore Database**).
3. Di Vercel, pilih **Framework Preset: Vite**, lalu klik **Deploy / Redeploy**.
